
<script src="Lib/JS/jquery.js"></script>
<script src="Lib/JS/bootstrap.min.js"></script>
<script src="JS/sign.js"></script>
<script src="JS/log.js"></script>
<script src="JS/resturent.js"></script>
<script src="JS/resRows.js"></script>
<script src="JS/displayItems.js"></script>
<script src="JS/search.js"></script>
</body>
</html>