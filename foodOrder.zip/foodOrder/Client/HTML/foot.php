<div class="foot-r">
<div class="container foo-t">
	<div class="footLinks">
	<a href="">Feedback</a>
	<a href="">Careers</a>
	<a href="">Terms</a>
	<a href="">FAQ</a>
	<a href="">Privacy</a>
	<a href="">Contact Us</a>
	<a href="">Sitemap</a>
    </div>
    <hr >
    <div class="social">
    <div>Follow us on</div>	
    <a href="#" class="fa fa-facebook social-m"></a>
    <a href="#" class="fa fa-twitter social-m"></a>
    <a href="#" class="fa fa-google social-m"></a>
    <a href="#" class="fa fa-youtube social-m"></a>
    <a href="#" class="fa fa-instagram social-m"></a>
    </div>
</div>
</div> 
</body>