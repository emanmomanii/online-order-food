<?php
	

	function lang($word) {
		$arr = array(

		'word1' => 'mean in ar',

		'word2' => 'meaning'

		);

		return $arr[$word];
	 }

 ?>