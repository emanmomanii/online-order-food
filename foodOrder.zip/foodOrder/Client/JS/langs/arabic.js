function lang(word) {
	var arr = [

	'word1' : 'mean in ar',

	'word2' : 'meaning'

	];

	return arr[word];
 }
